cat a >
