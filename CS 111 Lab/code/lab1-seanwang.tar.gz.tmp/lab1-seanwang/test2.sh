(cat > a )>b
(cat > a | ls)&&b
(
 

 cat > a | ls > b 


 )

(
 cat a
 )


(cat > a ) && (cat > b)

((a&&b)>a&&c)<b
