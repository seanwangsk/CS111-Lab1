#(cat > a )>b
#(cat > a | ls)&&b
(
 

 cat > a | ls > b 


 )

(
 cat a
 )


(cat > a ) && (cat > b)
