a|a&&b
